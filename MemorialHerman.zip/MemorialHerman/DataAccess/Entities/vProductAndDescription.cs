using System;
using System.Collections.Generic;

namespace DataAccess.Entities
{
	public class vProductAndDescription
	{
		public int ProductID { get; set; }
		public string Name { get; set; }
		public string ProductModel { get; set; }
		public string CultureID { get; set; }
		public string Description { get; set; }
	}
}

