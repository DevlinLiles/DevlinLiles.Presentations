﻿// Type: Castle.MicroKernel.Registration.Parameter
// Assembly: Castle.Windsor, Version=2.5.1.0, Culture=neutral, PublicKeyToken=407dd0808d44fbdc
// Assembly location: D:\Code\Fun\DallasTechFest\BeautifulUI\packages\Castle.Windsor.2.5.3\lib\NET40\Castle.Windsor.dll

using Castle.Core.Configuration;

namespace Castle.MicroKernel.Registration
{
  public class Parameter
  {
    private readonly string key;
    private readonly string value;
    private readonly IConfiguration configNode;

    public string Key
    {
      get
      {
        return this.key;
      }
    }

    public string Value
    {
      get
      {
        return this.value;
      }
    }

    public IConfiguration ConfigNode
    {
      get
      {
        return this.configNode;
      }
    }

    internal Parameter(string key, string value)
    {
      this.key = key;
      this.value = value;
    }

    internal Parameter(string key, IConfiguration configNode)
    {
      this.key = key;
      this.configNode = configNode;
    }

    public static ParameterKey ForKey(string key)
    {
      return new ParameterKey(key);
    }
  }
}
