﻿namespace Core.Domain
{
    public class Entity
    {
        public int Id { get; set; } 
    }
}